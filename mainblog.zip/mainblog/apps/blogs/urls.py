from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^blogs_apps$', views.blogs), #go to blogs method
    url(r'^new$', views.new), #go to new method
    url(r'^create$', views.create), #go to create method
    url(r'^(?P<blog_id>\d+)$', views.show), #go to show method
    url(r'^(?P<blog_id>\d+)/edit$', views.edit), #go to edit method
    url(r'^(?P<blog_id>\d+)/delete$', views.delete) #go to delete method
]
