from __future__ import unicode_literals

from django.apps import AppConfig


class PythonbeltprojectappConfig(AppConfig):
    name = 'pythonbeltprojectapp'
